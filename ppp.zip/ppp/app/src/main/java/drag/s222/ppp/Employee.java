package drag.s222.ppp;

public class Employee {
    public String empid;
    public String name;
    public Employee(String id, String name) {
        this.empid = id;
        this.name = name;
    }
}
