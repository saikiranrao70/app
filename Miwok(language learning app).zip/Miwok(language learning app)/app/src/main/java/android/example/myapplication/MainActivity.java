package android.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    public void openNumberList(View v){
        Intent i= new Intent(this, NumbersActivity.class);
        if(i!=null)
        startActivity(i);
    }
    public void openFamilyList(View v){
        Intent i= new Intent(this, FamilyActivity.class);
        if(i!=null)
        startActivity(i);
    }
    public void openColorsList(View v){
        Intent i= new Intent(this, ColorsActivity.class);
        if(i!=null)
        startActivity(i);
    }
    public void openPhrasesList(View v){
        Intent i= new Intent(this, PhrasesActivity.class);
        if(i!=null)
        startActivity(i);
    }
}
