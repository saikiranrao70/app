package android.example.com;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    int mainScoreA=0;
    int mainScoreB=0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    public void displayForTeamA(int score) {
        TextView scoreView = (TextView) findViewById(R.id.team_a_score);
        scoreView.setText("" + score);
    }
    public void displayForTeamB(int score) {
        TextView scoreView = (TextView) findViewById(R.id.team_b_score);
        scoreView.setText("" + score);
    }
    public void points_3A(View v){
        mainScoreA=mainScoreA+3;
        displayForTeamA(mainScoreA);
    }
    public void points_2A(View v){
        mainScoreA=mainScoreA+2;
        displayForTeamA(mainScoreA);
    }
    public void freethrowA(View v){
        mainScoreA=mainScoreA+1;
        displayForTeamA(mainScoreA);
    }
    public void points_3B(View v){
        mainScoreB=mainScoreB+3;
        displayForTeamB(mainScoreB);
    }
    public void points_2B(View v){
        mainScoreB=mainScoreB+2;
        displayForTeamB(mainScoreB);
    }
    public void freethrowB(View v){
        mainScoreB=mainScoreB+1;
        displayForTeamB(mainScoreB);
    }
    public void reset(View v){
        mainScoreA=0;
        mainScoreB=0;
        displayForTeamA(mainScoreA);
        displayForTeamB(mainScoreB);
    }
}