package drag.s222.earth;
import android.content.Context;
import android.view.View;
public class Word {
    private String city;
    private long date;
    private double rate;
    private String url;
    public Word(String mCity,long mDate,double mRate,String uurl){
city=mCity;
date=mDate;
rate=mRate;
url=uurl;
    }
public String getCity(){return city;}
public long getDate(){return date;}
public double getRate(){return rate;}
public String geturl(){return url;}
}
