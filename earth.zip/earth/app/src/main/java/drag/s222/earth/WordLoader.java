package drag.s222.earth;

import android.content.Context;

import androidx.loader.content.AsyncTaskLoader;

import java.util.ArrayList;
import java.util.List;

import android.app.LoaderManager;
import android.app.LoaderManager.LoaderCallbacks;
import android.content.Loader;


public class WordLoader extends AsyncTaskLoader<ArrayList<Word>>{
    private String mUrl;
    public WordLoader(Context context,String url){
        super(context);
        mUrl=url;
    }
    protected void onStartLoading() {
        forceLoad();
    }

    /**
     * This is on a background thread.
     * @return
     */
    @Override
    public ArrayList<Word> loadInBackground() {
        if (mUrl == null) {
            return null;
        }

        // Perform the network request, parse the response, and extract a list of earthquakes.
        ArrayList<Word> earthquakes = QueryUtils.extractEarthquakes(mUrl);
        return earthquakes;
    }
}