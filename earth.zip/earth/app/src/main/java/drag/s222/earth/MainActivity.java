package drag.s222.earth;

import android.content.Intent;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;
import android.app.LoaderManager;
import android.app.LoaderManager.LoaderCallbacks;
import android.content.Loader;


public class MainActivity extends AppCompatActivity {
    private static final int EARTHQUAKE_LOADER_ID = 1;
ArrayList<Word> data1=new ArrayList<Word>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        LoaderManager loaderManager = getLoaderManager();
loaderManager.initLoader(EARTHQUAKE_LOADER_ID,null,this);
    }
    public void updateui(ArrayList<Word> data){
        data1=data;
        WordActivity adapter = new WordActivity(this,data1);
        // Find a reference to the {@link ListView} in the layout
        ListView earthquakeListView = (ListView) findViewById(R.id.list);
        earthquakeListView.setAdapter(adapter);
        earthquakeListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {
                // Find the current earthquake that was clicked on
                Word currentEarthquake = adapter.getItem(position);

                // Convert the String URL into a URI object (to pass into the Intent constructor)
                Uri earthquakeUri = Uri.parse(currentEarthquake.geturl());

                // Create a new intent to view the earthquake URI
                Intent websiteIntent = new Intent(Intent.ACTION_VIEW, earthquakeUri);

                // Send the intent to launch a new activity
                startActivity(websiteIntent);
            }
        });
    }

    public void onLoadFinished(Loader<ArrayList<Word>> loader, ArrayList<Word> earthquakes) {
        // Clear the adapter of previous earthquake data
        data1.clear();

        // If there is a valid list of {@link Earthquake}s, then add them to the adapter's
        // data set. This will trigger the ListView to update.
        if (earthquakes != null && !earthquakes.isEmpty()) {
            data1.addAll(earthquakes);
            updateui(data1);
        }
    }
    public void onLoaderReset(Loader<ArrayList<Word>> loader) {
        // Loader reset, so we can clear out our existing data.
        data1.clear();
    }

  /*  private class EarthquakeAsyncTask extends AsyncTask<String, Void, ArrayList<Word>> {

        @Override
        protected ArrayList<Word> doInBackground(String... urls) {
ArrayList<Word> data=QueryUtils.extractEarthquakes(USGS_REQUEST_URL);
return data;

        }

        @Override
        protected void onPostExecute(ArrayList<Word> data) {
updateui(data);
        }
    }*/
}

