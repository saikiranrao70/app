package drag.s222.earth;
import android.os.Bundle;
import android.app.LoaderManager;
import android.app.LoaderManager.LoaderCallbacks;
import android.content.Loader;

import androidx.appcompat.app.AppCompatActivity;

import java.util.List;

import drag.s222.earth.Word;

public class EarthquakeActivity extends AppCompatActivity
        implements LoaderCallbacks<List<Word>> {

    private static final String USGS_REQUEST_URL ="https://earthquake.usgs.gov/fdsnws/event/1/query?format=geojson&orderby=time&minmag=6&limit=10";


    @Override
    public Loader<List<Word>> onCreateLoader(int i, Bundle bundle) {
        // TODO: Create a new loader for the given URL
        return new WordLoader(this, USGS_REQUEST_URL); }

    @Override
    public void onLoadFinished(Loader<List<Word>> loader, List<Word> earthquakes) {
        // TODO: Update the UI with the result


        // If there is a valid list of {@link Earthquake}s, then add them to the adapter's
        // data set. This will trigger the ListView to update.
        if (earthquakes != null && !earthquakes.isEmpty()) {


        }
    }

    @Override
    public void onLoaderReset(Loader<List<Word>> loader) {
        // TODO: Loader reset, so we can clear out our existing data.
    }
}