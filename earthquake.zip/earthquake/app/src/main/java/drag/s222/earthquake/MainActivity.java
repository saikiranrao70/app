package drag.s222.earthquake;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ListView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private static final String USGS_REQUEST_URL ="https://earthquake.usgs.gov/fdsnws/event/1/query?format=geojson&orderby=time&minmag=6&limit=10";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ArrayList<Earth> data=new ArrayList<Earth>();
        data.add(new Earth("sai",1142378790,1,"sai"));
        data.add(new Earth("sai",1142378790,1,"sai"));
        data.add(new Earth("sai",1142378790,1,"sai"));
        data.add(new Earth("sai",1142378790,1,"sai"));

        EarthAdapter adapter=new EarthAdapter(this, data);
        ListView listView = (ListView) findViewById(R.id.list);
        listView.setAdapter(adapter);
    }
}