package drag.s222.earthquake;
public class Earth {
    private String city;
    private long date;
    private double rate;
    private String url;

    public Earth(String mCity, long mDate, double mRate, String uurl) {
        city = mCity;
        date = mDate;
        rate = mRate;
        url = uurl;
    }

    public String getCity(){return city;}
    public long getDate(){return date;}
    public double getRate(){return rate;}
    public String geturl(){return url;}
}